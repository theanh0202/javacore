package com.vti.entity;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Manager extends User{
    private int expInYear;
}
