package com.vti.entity;

public enum Role {
     MANAGER,EMPLOYEE
}
