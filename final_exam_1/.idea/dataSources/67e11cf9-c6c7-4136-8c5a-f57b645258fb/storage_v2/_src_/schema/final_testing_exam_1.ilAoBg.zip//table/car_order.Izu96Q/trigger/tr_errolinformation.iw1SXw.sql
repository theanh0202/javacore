create definer = root@localhost trigger tr_errolinformation
    before insert
    on car_order
    for each row
begin
   declare de_customerid date;
   set de_customerid = (select customerid from car_order where deliverydate < orderdate + 15);
   if (de_customerid= new.customerid)
   then 
	SIGNAL SQLSTATE '12345' 
	SET MESSAGE_TEXT = 'Cant insert This Exam!!'; 
	END IF ;  
	END;

