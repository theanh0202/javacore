create
    definer = root@localhost procedure pr_makersalemax()
begin
	select ca.maker
    from car_order co
    join car ca on ca.carid=co.carid
    group by carid
	having (co.carid)=(select count(carid) from car_order order by carid desc limit 1);
end;

