package com.vti.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Employee extends User{
    private String proSkill;
}
